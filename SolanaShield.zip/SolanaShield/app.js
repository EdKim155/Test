const express = require('express');
const securityMiddleware = require('./middleware/security');
const rateLimitConfig = require('./middleware/rateLimit');
const securityHeaders = require('./security/headers');
const monitor = require('./utils/monitor');
const axios = require('axios');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

const app = express();

app.use(express.static('public'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

securityMiddleware.setup(app);

app.use('/api/', rateLimitConfig.apiLimiter);
app.use('/api/auth', rateLimitConfig.authLimiter);
app.use('/api/solana', rateLimitConfig.solanaLimiter);

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.get('/api/solana/price', async (req, res) => {
    try {
        const response = await axios.get('https://api.coingecko.com/api/v3/simple/price', {
            params: {
                ids: 'solana',
                vs_currencies: 'usd',
                include_24hr_change: true
            }
        });

        const { usd: price, usd_24h_change: change } = response.data.solana;
        res.json({
            price: price.toFixed(2),
            change: change.toFixed(2)
        });
    } catch (error) {
        console.error('Error fetching Solana price:', error);
        res.status(500).json({ error: 'Failed to fetch Solana price' });
    }
});

app.get('/api/solana/dex-info', async (req, res) => {
    try {
        const { stdout } = await execPromise('python3 utils/dex_scraper.py');
        const dexData = JSON.parse(stdout);

        if (!dexData) {
            throw new Error('Failed to fetch DEX data');
        }

        res.json(dexData);
    } catch (error) {
        console.error('Error fetching DEX data:', error);
        res.status(500).json({ error: 'Failed to fetch DEX data' });
    }
});

app.use((err, req, res, next) => {
    console.error('Error:', err);
    monitor.recordError(err, { path: req.path, method: req.method });
    res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
});

module.exports = app;