const request = require('supertest');
const app = require('../app'); // Adjust path as needed

describe('API Endpoint Tests', () => {
    describe('GET /api/health', () => {
        it('should return 200 OK', async () => {
            const response = await request(app)
                .get('/api/health')
                .expect(200);
            
            expect(response.body.status).toBe('ok');
        });
    });

    describe('Rate Limiting Tests', () => {
        it('should limit excessive requests', async () => {
            // Make multiple requests to trigger rate limit
            for(let i = 0; i < 101; i++) {
                const response = await request(app)
                    .get('/api/solana/price');
                
                if(i === 100) {
                    expect(response.status).toBe(429);
                    expect(response.body.error).toContain('Too many requests');
                }
            }
        });
    });

    describe('Security Headers', () => {
        it('should have proper security headers', async () => {
            const response = await request(app)
                .get('/api/health');
            
            expect(response.headers['x-frame-options']).toBe('DENY');
            expect(response.headers['x-xss-protection']).toBe('1; mode=block');
            expect(response.headers['x-content-type-options']).toBe('nosniff');
        });
    });
});
