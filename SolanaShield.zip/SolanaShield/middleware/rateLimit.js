const rateLimit = require('express-rate-limit');

const rateLimitConfig = {
    // General API rate limit
    apiLimiter: rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100, // limit each IP to 100 requests per windowMs
        message: {
            error: 'Too many requests, please try again later.'
        }
    }),

    // Stricter limit for authentication endpoints
    authLimiter: rateLimit({
        windowMs: 60 * 60 * 1000, // 1 hour
        max: 5, // limit each IP to 5 requests per windowMs
        message: {
            error: 'Too many authentication attempts, please try again later.'
        }
    }),

    // Custom limiter for Solana API endpoints
    solanaLimiter: rateLimit({
        windowMs: 5 * 60 * 1000, // 5 minutes
        max: 50, // limit each IP to 50 requests per windowMs
        message: {
            error: 'Rate limit exceeded for Solana API requests.'
        }
    })
};

module.exports = rateLimitConfig;