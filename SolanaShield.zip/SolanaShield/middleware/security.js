const helmet = require('helmet');
const express = require('express');
const hpp = require('hpp');
const mongoSanitize = require('express-mongo-sanitize');

const securityMiddleware = {
    // Basic security middleware setup
    setup: (app) => {
        // Use Helmet for security headers
        app.use(helmet());
        
        // Prevent parameter pollution
        app.use(hpp());
        
        // Sanitize MongoDB queries
        app.use(mongoSanitize());
        
        // Enable CORS with strict options
        app.use((req, res, next) => {
            res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGINS || '*');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            next();
        });

        // Add custom security headers
        app.use((req, res, next) => {
            res.setHeader('X-Content-Type-Options', 'nosniff');
            res.setHeader('X-Frame-Options', 'DENY');
            res.setHeader('X-XSS-Protection', '1; mode=block');
            next();
        });

        // Request validation middleware
        app.use((req, res, next) => {
            if (req.body && typeof req.body === 'object') {
                // Validate request size
                const requestSize = JSON.stringify(req.body).length;
                if (requestSize > 1000000) { // 1MB limit
                    return res.status(413).json({ error: 'Payload too large' });
                }
            }
            next();
        });
    }
};

module.exports = securityMiddleware;
