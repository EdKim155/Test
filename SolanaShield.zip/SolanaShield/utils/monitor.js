const winston = require('winston');

class Monitor {
    constructor() {
        this.logger = winston.createLogger({
            level: 'info',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.json()
            ),
            transports: [
                new winston.transports.File({ filename: 'error.log', level: 'error' }),
                new winston.transports.File({ filename: 'combined.log' })
            ]
        });

        if (process.env.NODE_ENV !== 'production') {
            this.logger.add(new winston.transports.Console({
                format: winston.format.simple()
            }));
        }

        // In-memory request counter
        this.requestCounts = new Map();
    }

    async logRequest(req) {
        const requestData = {
            timestamp: new Date().toISOString(),
            ip: req.ip,
            method: req.method,
            path: req.path,
            userAgent: req.headers['user-agent']
        };

        // Log to Winston
        this.logger.info('API Request', requestData);

        // Update in-memory counter
        const key = `${req.path}:${new Date().getHours()}`;
        this.requestCounts.set(key, (this.requestCounts.get(key) || 0) + 1);
    }

    async checkThreshold(path, threshold = 1000) {
        const key = `${path}:${new Date().getHours()}`;
        const count = this.requestCounts.get(key) || 0;
        if (count > threshold) {
            this.logger.warn(`High traffic detected on ${path}: ${count} requests`);
            return true;
        }
        return false;
    }

    async recordError(error, context = {}) {
        const errorData = {
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
            context
        };

        this.logger.error('Application Error', errorData);
    }
}

module.exports = new Monitor();