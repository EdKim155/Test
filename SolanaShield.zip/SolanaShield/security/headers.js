const securityHeaders = {
    // CSP Header configuration
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", 'https://cdn.jsdelivr.net'],
            styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
            imgSrc: ["'self'", 'data:', 'https:'],
            connectSrc: ["'self'", 'https://api.solana.com'],
            fontSrc: ["'self'", 'https://fonts.gstatic.com'],
            objectSrc: ["'none'"],
            mediaSrc: ["'self'"],
            frameSrc: ["'none'"]
        }
    },

    // HSTS configuration
    strictTransportSecurity: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
    },

    // Referrer Policy
    referrerPolicy: {
        policy: 'strict-origin-when-cross-origin'
    },

    // Feature Policy
    featurePolicy: {
        features: {
            geolocation: ["'none'"],
            midi: ["'none'"],
            notifications: ["'none'"],
            push: ["'none'"],
            syncXhr: ["'none'"],
            microphone: ["'none'"],
            camera: ["'none'"],
            magnetometer: ["'none'"],
            gyroscope: ["'none'"],
            speaker: ["'none'"],
            vibrate: ["'none'"],
            fullscreen: ["'self'"],
            payment: ["'none'"]
        }
    }
};

module.exports = securityHeaders;
